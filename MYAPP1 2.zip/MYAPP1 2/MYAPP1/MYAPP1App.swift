//
//  MYAPP1App.swift
//  MYAPP1
//
//  Created by Khristina Valevskaia on 10.06.2022.
//

import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
